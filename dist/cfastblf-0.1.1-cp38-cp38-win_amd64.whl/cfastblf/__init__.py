__version__ = "0.1.0"

from .cfastblf import read, write, to_homo, to_index_chunk, signal_decoder
from .canqry import Query

# 控制导出
__all__ = [
    "read",  # 返回 index, chunk 元组
    "write", # 输入必须是齐次数组 
    "to_homo", # index_chunk 转齐次数组
    "to_index_chunk", # 齐次数组 转 index_chunk
    "signal_decoder", # 获取特定信号的解析函数
    "Query", # CAN查询器
]
# 防止子模块直接暴露
del globals()["cfastblf"]
del globals()["canqry"]

